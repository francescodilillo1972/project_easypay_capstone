package com.easypay.dockerspringwebboot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DockerSpringwebBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
